
            <section class="hero" id="hero">
                <div class="container" dir="rtl">
                    <div class="row">

                        <div class="col-12">
                            <div id="myCarousel" class="carousel slide carousel-fade" data-bs-ride="carousel">
                                <div class="carousel-inner">
                                    <div class="carousel-item active">
                                        <img src="images/slider/portrait-successful-mid-adult-doctor-with-crossed-arms.jpg" class="img-fluid" alt="">
                                    </div>

                                    <div class="carousel-item">
                                        <img src="images/slider/young-asian-female-dentist-white-coat-posing-clinic-equipment.jpg" class="img-fluid" alt="">
                                    </div>

                                    <div class="carousel-item">
                                        <img src="images/slider/doctor-s-hand-holding-stethoscope-closeup.jpg" class="img-fluid" alt="">
                                    </div>
                                </div>
                            </div>

                            <div class="heroText d-flex flex-column justify-content-center">

                                <h1 class="mt-auto mb-2">
                                   حياة
                                    <div class="animated-info">
                                        <span class="animated-item">اجمل</span>
                                        <span class="animated-item">اروع</span>
                                        <span class="animated-item">اسعد</span>
                                    </div>
                                </h1>

                                <p class="mb-4">.زراعة الاسنان صارت أسهل و أسرع  </p>

                                
                                
                            </div>
                        </div>

                    </div>
                </div>
            </section>