<section class="section-padding pb-0" id="reviews">
    <div class="container">
        <div class="row">

            <div class="col-12">
               
                <h2 class="text-center mb-lg-5 mb-4">فريق العمل</h2>
                <br>



                <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="false">
                    <div class="carousel-indicators">
                      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
                      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
                    </div>
                    <div class="carousel-inner">
                      <div class="carousel-item active">
                        <p style="text-align:center;"> <img  src=" <?php echo e(url('images/sd.webp')); ?>" width="400" height="650" alt="..."></p>
                        <div class="carousel-caption d-none d-md-block">
                          <h5> </h5>
                          <p> </p>
                        </div>
                      </div>


                      <div class="carousel-item">
                        <p style="text-align:center;"> <img  src=" <?php echo e(url('images/td.webp')); ?>" width="400" height="650" alt="..."></p>
                        <div class="carousel-caption d-none d-md-block">
                          <h5> </h5>
                          <p> </p>
                        </div>
                      </div>
                      <div class="carousel-item">
                        <p style="text-align:center;"> <img  src=" <?php echo e(url('images/fd.webp')); ?>" width="400" height="650" alt="..."></p>
                       
                        <div class="carousel-caption d-none d-md-block">
                          <h5></h5>
                          <p></p>
                        </div>
                      </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                      <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                      <span class="carousel-control-next-icon" aria-hidden="true"></span>
                      <span class="visually-hidden">Next</span>
                    </button>
                  </div>
            </div>

        </div>
    </div>
</section><?php /**PATH C:\wamp4\www\nafedadoctors\resources\views/review.blade.php ENDPATH**/ ?>