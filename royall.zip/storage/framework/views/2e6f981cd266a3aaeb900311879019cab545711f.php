<section class="section-padding" id="about" dir="rtl">
    <div class="container">
        <div class="row">

            <div class="col-lg-6 col-md-6 col-12" >
                <h2 class="mb-lg-3 mb-3">عيادة رويال</h2>
<p> نخبة من أفضل الاستشاريين والاخصائيين </p>
<br>
   
<p> 
    





    نعتبر أنفسنا من الرواد في هذا المجال بأسماء أطبائنا الذين هم جزء لا يتجزأ من كياننا ومن الجسم الطبي في المملكة العربية السعودية.










</p>

<br>
 
    <p>
        أجهزة متطورة ومواد طبية عالمية




    </p>
    <br>
                    <p>
                        
                    
نستخدم افضل الأجهزة المتطورة في القطاع الطبي والمواد الطبية المستخدمة الافضل عالميا وذلك لنقدم خدمة طبية متكاملة
                    
                    </p>


                    <br>
                <p>.</p>

                <br>
                <p></p>
                <br>
                                <p>.</p>
                
            </div>

            
        </div>
    </div>
</section><?php /**PATH C:\wamp4\www\nafedadoctors\resources\views/about.blade.php ENDPATH**/ ?>