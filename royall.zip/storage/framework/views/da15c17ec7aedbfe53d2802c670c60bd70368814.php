<body id="top" >
    
    <main>

        <nav class="navbar navbar-expand-lg bg-light fixed-top shadow-lg">
            <div class="container" dir="rtl">

               
                <img src="<?php echo e(asset('logo.webp')); ?>"     width="100" height="100">
                <?php echo $__env->make('success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                       

                <a class="navbar-brand mx-auto d-lg-none" href="index.html">
                    عيادات رويال 

                     
                    <br>
                    <strong class="d-block"> أفضل رعاية طبية نقدمها لكم  </strong>
                </a>

              
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav mx-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="#hero">الرئيسية</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="#about">من نحن</a>
                        </li>

                       

                        <a class="navbar-brand d-none d-lg-block" href="index.html">
                            عيادة
                            <strong class="d-block">رويال</strong>
                        </a>

                        

                        <li class="nav-item">
                            <a class="nav-link" href="#booking">حجز موعد</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="#contact">تواصل معنا</a>
                        </li>
                    </ul>
                </div>

            </div>
        </nav><?php /**PATH C:\wamp4\www\nafedadoctors\resources\views/top.blade.php ENDPATH**/ ?>